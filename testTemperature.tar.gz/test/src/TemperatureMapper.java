
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TemperatureMapper extends Mapper<Text, Text, Text, DoubleWritable> {

@Override

public void map(Text key, Text value, Context context) throws IOException,

InterruptedException {

if (isValueValid(value.toString())) {

Text key2 = new Text(getStateFromValue(value.toString()));

DoubleWritable value2 = new DoubleWritable(

getTemperatureFrom(value.toString()));

context.write(key2, value2);

}

}

private boolean isValueValid(final String value) {

// We expect that the value is a String in the form of : State,

// Temperature. E.g. MP,77

Pattern p = Pattern.compile("\\S\\S\\,\\d+");

Matcher m = p.matcher(value);

return m.matches();

}

private String getStateFromValue(final String value) {

final String[] subvalues = value.split("\\,");

return subvalues[0];

}

private int getTemperatureFrom(final String value) {

final String[] subvalues = value.split("\\,");

return Integer.parseInt(subvalues[1]);

}

}