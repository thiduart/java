
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Reducer;

public class TemperatureReducer extends

Reducer<Text, DoubleWritable, Text, DoubleWritable> {

@Override

protected void reduce(final Text key,

final Iterable<DoubleWritable> values, final Context context)

throws IOException, InterruptedException {

double sumOfTemperatures = 0;

double nbValues = 0;

for (DoubleWritable temperature : values) {

sumOfTemperatures += temperature.get();

nbValues++;

}

double average = sumOfTemperatures / nbValues;

context.write(key, new DoubleWritable(average));

}

}